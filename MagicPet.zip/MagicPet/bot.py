import asyncio
import json
import random
import sqlite3
import time
from pathlib import Path

from aiogram import Bot, Dispatcher, F
from aiohttp import web
from aiogram.filters import Command
from aiogram.types import (
    Message,
    CallbackQuery,
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
)

from PIL import Image, ImageDraw, ImageFont

BASE_DIR = Path(__file__).resolve().parent
IMAGE_DIR = BASE_DIR / "pet_images"
GENERATED_DIR = BASE_DIR / "generated"
DB_PATH = BASE_DIR / "pets.db"

GENERATED_DIR.mkdir(exist_ok=True)

# =========================================================
# MAGICPET - полная версия
# =========================================================
# 1. Вставь токен своего Telegram-бота в BOT_TOKEN.
# 2. Рядом с bot.py должна быть папка pet_images с PNG-картинками.
# 3. Не отправляй токен никому и не публикуй его в скриншотах.

BOT_TOKEN = "9222432182:AAH8DfLwDyOpLdFe8fXqX8jf0MZpKHgC1n8"

BOT_TOKEN = BOT_TOKEN.strip()

if not BOT_TOKEN or BOT_TOKEN == "ВСТАВЬ_СЮДА_НОВЫЙ_ТОКЕН":
    raise RuntimeError("Вставь токен Telegram-бота")

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()

WEBAPP_DIR = BASE_DIR / "webapp"
WEBAPP_HOST = "127.0.0.1"
WEBAPP_PORT = 8080
# ---------------------------------------------------------
# Питомцы и предметы
# ---------------------------------------------------------

PETS = [
    {"name": "Дракончик", "emoji": "🐉", "image": "dragon.png"},
    {"name": "Единорог", "emoji": "🦄", "image": "unicorn.png"},
    {"name": "Волшебная лисичка", "emoji": "🦊", "image": "fox.png"},
    {"name": "Феникс", "emoji": "🔥", "image": "phoenix.png"},
    {"name": "Крылатый котик", "emoji": "🐱", "image": "winged_cat.png"},
    {"name": "Маленький дракон", "emoji": "🐲", "image": "little_dragon.png"},
]

DECORATIONS = {
    "crown": {
        "name": "Золотая корона", "emoji": "👑",
        "price": 50, "sell": 25, "description": "Королевский образ",
    },
    "bow": {
        "name": "Розовый бантик", "emoji": "🎀",
        "price": 30, "sell": 15, "description": "Милый бантик",
    },
    "glasses": {
        "name": "Очки", "emoji": "🕶️",
        "price": 40, "sell": 20, "description": "Стильные очки",
    },
    "halo": {
        "name": "Волшебный нимб", "emoji": "😇",
        "price": 60, "sell": 30, "description": "Сияющий нимб",
    },
}

# ---------------------------------------------------------
# База данных и обновление старой базы
# ---------------------------------------------------------

def db_connect():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db_connect() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS players (
                user_id INTEGER PRIMARY KEY,
                username TEXT,
                pet_name TEXT,
                pet_emoji TEXT,
                pet_image TEXT,
                coins INTEGER DEFAULT 100,
                level INTEGER DEFAULT 1,
                xp INTEGER DEFAULT 0,
                hunger INTEGER DEFAULT 100,
                thirst INTEGER DEFAULT 100,
                energy INTEGER DEFAULT 100,
                happiness INTEGER DEFAULT 100,
                hygiene INTEGER DEFAULT 100,
                inventory TEXT DEFAULT '{}',
                equipped TEXT DEFAULT '',
                last_update REAL DEFAULT 0
            )
        """)

        existing = {
            row["name"]
            for row in conn.execute("PRAGMA table_info(players)").fetchall()
        }
        columns = {
            "username": "TEXT",
            "pet_name": "TEXT",
            "pet_emoji": "TEXT",
            "pet_image": "TEXT",
            "coins": "INTEGER DEFAULT 100",
            "level": "INTEGER DEFAULT 1",
            "xp": "INTEGER DEFAULT 0",
            "hunger": "INTEGER DEFAULT 100",
            "thirst": "INTEGER DEFAULT 100",
            "energy": "INTEGER DEFAULT 100",
            "happiness": "INTEGER DEFAULT 100",
            "hygiene": "INTEGER DEFAULT 100",
            "inventory": "TEXT DEFAULT '{}'",
            "equipped": "TEXT DEFAULT ''",
            "last_update": "REAL DEFAULT 0",
        }
        for column, definition in columns.items():
            if column not in existing:
                conn.execute(
                    f"ALTER TABLE players ADD COLUMN {column} {definition}"
                )

        # Старым питомцам задаём время последнего обновления,
        # чтобы при первом запуске показатели не упали резко.
        conn.execute(
            "UPDATE players SET last_update = ? WHERE last_update IS NULL OR last_update = 0",
            (time.time(),)
        )

        # Переносим старых питомцев на новые имена файлов картинок.
        image_by_name = {
            "Дракончик": "dragon.png",
            "Единорог": "unicorn.png",
            "Волшебная лисичка": "fox.png",
            "Феникс": "phoenix.png",
            "Крылатый котик": "winged_cat.png",
            "Маленький дракон": "little_dragon.png",
        }
        for pet_name, filename in image_by_name.items():
            conn.execute(
                "UPDATE players SET pet_image = ? WHERE pet_name = ? AND (pet_image IS NULL OR pet_image = '')",
                (filename, pet_name)
            )


def get_pet(user_id):
    with db_connect() as conn:
        row = conn.execute(
            "SELECT * FROM players WHERE user_id = ?", (user_id,)
        ).fetchone()
        if not row:
            return None
        pet = dict(row)

    try:
        pet["inventory_data"] = json.loads(pet.get("inventory") or "{}")
    except (json.JSONDecodeError, TypeError):
        pet["inventory_data"] = {}

    return pet


def save_new_pet(user_id, username, pet):
    with db_connect() as conn:
        conn.execute("""
            INSERT INTO players (
                user_id, username, pet_name, pet_emoji, pet_image,
                coins, level, xp, hunger, thirst, energy, happiness,
                hygiene, inventory, equipped, last_update
            )
            VALUES (?, ?, ?, ?, ?, 100, 1, 0, 100, 100, 100, 100, 100, '{}', '', ?)
            ON CONFLICT(user_id) DO UPDATE SET
                username = excluded.username,
                pet_name = excluded.pet_name,
                pet_emoji = excluded.pet_emoji,
                pet_image = excluded.pet_image,
                coins = 100,
                level = 1,
                xp = 0,
                hunger = 100,
                thirst = 100,
                energy = 100,
                happiness = 100,
                hygiene = 100,
                inventory = '{}',
                equipped = '',
                last_update = excluded.last_update
        """, (
            user_id, username, pet["name"], pet["emoji"],
            pet["image"], time.time()
        ))


def update_pet_fields(user_id, **fields):
    allowed = {
        "username", "coins", "level", "xp", "hunger", "thirst",
        "energy", "happiness", "hygiene", "inventory", "equipped",
        "last_update",
    }
    fields = {k: v for k, v in fields.items() if k in allowed}
    if not fields:
        return
    assignments = ", ".join(f"{key} = ?" for key in fields)
    values = list(fields.values()) + [user_id]
    with db_connect() as conn:
        conn.execute(
            f"UPDATE players SET {assignments} WHERE user_id = ?", values
        )


def clamp(value):
    return max(0, min(100, int(value)))


def apply_time_decay(user_id):
    """Уменьшает потребности за прошедшее время, а не только пока бот открыт."""
    pet = get_pet(user_id)
    if not pet or not pet.get("pet_name"):
        return pet

    now = time.time()
    last = float(pet.get("last_update") or now)
    elapsed_periods = int(max(0, now - last) // 600)  # один игровой шаг = 10 минут

    if elapsed_periods > 0:
        # Потери за каждые 10 минут.
        pet["hunger"] = clamp(pet["hunger"] - 3 * elapsed_periods)
        pet["thirst"] = clamp(pet["thirst"] - 4 * elapsed_periods)
        pet["energy"] = clamp(pet["energy"] - 2 * elapsed_periods)
        pet["happiness"] = clamp(pet["happiness"] - 2 * elapsed_periods)
        pet["hygiene"] = clamp(pet["hygiene"] - 1 * elapsed_periods)

        # Сдвигаем отметку на целое число периодов, сохраняя остаток времени.
        new_last = last + elapsed_periods * 600
        update_pet_fields(
            user_id,
            hunger=pet["hunger"],
            thirst=pet["thirst"],
            energy=pet["energy"],
            happiness=pet["happiness"],
            hygiene=pet["hygiene"],
            last_update=new_last,
        )
        pet = get_pet(user_id)

    return pet


def add_rewards(user_id, xp=0, coins=0, **stat_changes):
    pet = apply_time_decay(user_id)
    if not pet:
        return None

    values = {
        "coins": max(0, pet["coins"] + coins),
        "xp": pet["xp"] + xp,
        "level": pet["level"],
        "hunger": pet["hunger"],
        "thirst": pet["thirst"],
        "energy": pet["energy"],
        "happiness": pet["happiness"],
        "hygiene": pet["hygiene"],
    }

    for key, amount in stat_changes.items():
        if key in ("hunger", "thirst", "energy", "happiness", "hygiene"):
            values[key] = clamp(values[key] + amount)

    level_ups = 0
    while values["xp"] >= values["level"] * 50:
        values["xp"] -= values["level"] * 50
        values["level"] += 1
        values["coins"] += 25
        level_ups += 1

    update_pet_fields(user_id, **values)
    return get_pet(user_id), level_ups


# ---------------------------------------------------------
# Рост и визуальный облик
# ---------------------------------------------------------

def growth_stage(level):
    if level <= 5:
        return "Малыш", "🐣"
    if level <= 15:
        return "Подросток", "🐾"
    if level <= 30:
        return "Взрослый", "✨"
    return "Легендарный", "🌟"


def xp_needed(level):
    return level * 50


def make_pet_image(pet):
    """Создаёт картинку питомца с надетым украшением и отметкой стадии роста."""
    GENERATED_DIR.mkdir(exist_ok=True)
    source = IMAGE_DIR / (pet.get("pet_image") or "")

    if not source.is_file():
        return None

    try:
        image = Image.open(source).convert("RGBA")
        # По мере взросления питомец занимает больше места на карточке.
        level = int(pet.get("level") or 1)
        scale = 0.78 if level <= 5 else 0.88 if level <= 15 else 0.96 if level <= 30 else 1.0
        target_size = int(640 * scale)
        image.thumbnail((target_size, target_size))
        canvas = Image.new("RGBA", (680, 760), (245, 240, 255, 255))
        x = (680 - image.width) // 2
        y = 65 + (640 - image.height) // 2
        canvas.alpha_composite(image, (x, y))

        draw = ImageDraw.Draw(canvas)
        try:
            font_big = ImageFont.truetype("arial.ttf", 30)
            font_small = ImageFont.truetype("arial.ttf", 22)
        except OSError:
            font_big = ImageFont.load_default()
            font_small = ImageFont.load_default()

        stage, stage_emoji = growth_stage(pet["level"])
        draw.rounded_rectangle((12, 12, 668, 58), radius=18, fill=(95, 65, 150, 235))
        draw.text((28, 20), f"{stage_emoji} {stage} • Уровень {pet['level']}",
                  fill="white", font=font_big)

        # Координаты аксессуаров относительно изображения питомца.
        left, top, right, bottom = x, y, x + image.width, y + image.height
        cx = (left + right) // 2
        head_y = top + int(image.height * 0.20)
        decor = pet.get("equipped") or ""

        if decor == "crown":
            # Корона из золотых геометрических фигур.
            base_y = head_y + 8
            draw.rectangle((cx - 65, base_y, cx + 65, base_y + 20),
                           fill=(255, 190, 25, 255), outline=(130, 80, 0, 255), width=4)
            draw.polygon(
                [(cx - 65, base_y), (cx - 55, base_y - 48),
                 (cx - 20, base_y - 12), (cx, base_y - 58),
                 (cx + 22, base_y - 12), (cx + 55, base_y - 48),
                 (cx + 65, base_y)],
                fill=(255, 205, 35, 255), outline=(130, 80, 0, 255)
            )
            for px in (cx - 42, cx, cx + 42):
                draw.ellipse((px - 6, base_y - 8, px + 6, base_y + 4),
                             fill=(255, 70, 100, 255))

        elif decor == "bow":
            bx, by = cx + 55, head_y + 12
            draw.polygon([(bx, by), (bx - 45, by - 32), (bx - 42, by + 25)],
                         fill=(255, 90, 160, 255), outline=(150, 30, 90, 255))
            draw.polygon([(bx, by), (bx + 45, by - 32), (bx + 42, by + 25)],
                         fill=(255, 90, 160, 255), outline=(150, 30, 90, 255))
            draw.ellipse((bx - 12, by - 12, bx + 12, by + 12),
                         fill=(255, 210, 230, 255))

        elif decor == "glasses":
            gy = top + int(image.height * 0.43)
            gx1, gx2 = cx - 48, cx + 48
            draw.rounded_rectangle((gx1 - 30, gy - 18, gx1 + 25, gy + 20),
                                   radius=10, fill=(30, 35, 55, 220),
                                   outline=(15, 15, 20, 255), width=5)
            draw.rounded_rectangle((gx2 - 25, gy - 18, gx2 + 30, gy + 20),
                                   radius=10, fill=(30, 35, 55, 220),
                                   outline=(15, 15, 20, 255), width=5)
            draw.line((gx1 + 25, gy, gx2 - 25, gy), fill=(15, 15, 20, 255), width=6)

        elif decor == "halo":
            hy = top + int(image.height * 0.12)
            draw.ellipse((cx - 65, hy - 15, cx + 65, hy + 15),
                         outline=(255, 205, 35, 255), width=10)

        # Нижняя плашка показывает надетое украшение.
        decor_label = DECORATIONS.get(decor, {}).get("name", "Без украшения")
        draw.rounded_rectangle((12, 700, 668, 748), radius=16, fill=(95, 65, 150, 235))
        draw.text((28, 710), f"Украшение: {decor_label}",
                  fill="white", font=font_small)

        output = GENERATED_DIR / f"pet_{pet['user_id']}.png"
        canvas.convert("RGB").save(output, quality=92)
        return output
    except Exception as error:
        print("Ошибка создания изображения:", error)
        return None


def pet_caption(pet):
    stage, stage_emoji = growth_stage(pet["level"])
    decor = DECORATIONS.get(pet.get("equipped") or "")
    decor_text = f"{decor['emoji']} {decor['name']}" if decor else "Нет"

    return (
        f"{pet['pet_emoji']} {pet['pet_name']}\n"
        f"{stage_emoji} Стадия: {stage}\n"
        f"⭐ Уровень: {pet['level']}  •  ✨ Опыт: {pet['xp']}/{xp_needed(pet['level'])}\n"
        f"🪙 Монеты: {pet['coins']}\n\n"
        f"🍎 Сытость: {pet['hunger']}/100\n"
        f"💧 Жажда: {pet['thirst']}/100\n"
        f"⚡ Энергия: {pet['energy']}/100\n"
        f"💖 Счастье: {pet['happiness']}/100\n"
        f"🛁 Чистота: {pet['hygiene']}/100\n"
        f"👑 Украшение: {decor_text}"
    )


# ---------------------------------------------------------
# Анимации мини-игр
# ---------------------------------------------------------

def make_game_gif(user_id, game):
    GENERATED_DIR.mkdir(exist_ok=True)
    pet = get_pet(user_id)
    if not pet:
        return None

    source = IMAGE_DIR / (pet.get("pet_image") or "")
    if source.is_file():
        base = Image.open(source).convert("RGBA")
        base.thumbnail((440, 440))
    else:
        base = Image.new("RGBA", (440, 440), (245, 240, 255, 255))

    frames = []
    for i in range(8):
        frame = Image.new("RGBA", (480, 520), (245, 240, 255, 255))
        x = (480 - base.width) // 2
        y = 30 + (440 - base.height) // 2
        frame.alpha_composite(base, (x, y))
        draw = ImageDraw.Draw(frame)

        if game == "stick":
            # Палка движется по дуге, питомец как будто бежит за ней.
            stick_x = 45 + i * 48
            stick_y = 430 - int(65 * (1 - abs(3.5 - i) / 4))
            draw.line((stick_x - 24, stick_y + 12, stick_x + 24, stick_y - 12),
                      fill=(120, 70, 25, 255), width=12)
            draw.ellipse((stick_x - 7, stick_y - 20, stick_x + 7, stick_y - 6),
                         fill=(170, 110, 50, 255))
        elif game == "pet":
            # Сердечки поднимаются над питомцем.
            for j in range(3):
                hx = 100 + j * 135
                hy = 150 - ((i * 18 + j * 35) % 110)
                draw.ellipse((hx - 9, hy - 9, hx + 9, hy + 9),
                             fill=(255, 90, 140, 230))
                draw.ellipse((hx + 3, hy - 9, hx + 21, hy + 9),
                             fill=(255, 90, 140, 230))
                draw.polygon([(hx - 9, hy), (hx + 21, hy), (hx + 6, hy + 22)],
                             fill=(255, 90, 140, 230))
        else:
            # Мяч перемещается по экрану.
            bx = 50 + i * 52
            by = 440 - int(70 * abs(3.5 - i) / 4)
            draw.ellipse((bx - 22, by - 22, bx + 22, by + 22),
                         fill=(70, 160, 255, 255), outline=(30, 70, 150, 255), width=4)
            draw.line((bx - 18, by, bx + 18, by), fill="white", width=3)

        frames.append(frame.convert("P", palette=Image.Palette.ADAPTIVE))

    output = GENERATED_DIR / f"game_{user_id}_{game}.gif"
    frames[0].save(
        output, save_all=True, append_images=frames[1:],
        duration=140, loop=0, optimize=False
    )
    return output


# ---------------------------------------------------------
# Клавиатуры и отправка профиля
# ---------------------------------------------------------

main_keyboard = ReplyKeyboardMarkup(
    keyboard=[
        [KeyboardButton(text="🥚 Вылупить питомца"), KeyboardButton(text="🐾 Мой питомец")],
        [KeyboardButton(text="🎮 Поиграть"), KeyboardButton(text="👑 Украшения")],
        [KeyboardButton(text="🎒 Инвентарь"), KeyboardButton(text="🛍️ Магазин")],
    ],
    resize_keyboard=True,
)


def care_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🍎 Покормить", callback_data="care_feed"),
            InlineKeyboardButton(text="💧 Напоить", callback_data="care_drink"),
        ],
        [
            InlineKeyboardButton(text="😴 Сон", callback_data="care_sleep"),
            InlineKeyboardButton(text="🛁 Помыть", callback_data="care_wash"),
        ],
    ])


def games_keyboard():
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❤️ Почесать питомца", callback_data="game_pet")],
        [InlineKeyboardButton(text="🦴 Кинуть палку", callback_data="game_stick")],
        [InlineKeyboardButton(text="🎾 Поймать мяч", callback_data="game_ball")],
    ])


def shop_keyboard():
    buttons = []
    for key, item in DECORATIONS.items():
        buttons.append([
            InlineKeyboardButton(
                text=f"{item['emoji']} {item['name']} — {item['price']} 🪙",
                callback_data=f"buy_{key}"
            )
        ])
    return InlineKeyboardMarkup(inline_keyboard=buttons)


def inventory_keyboard(pet):
    rows = []
    inventory = pet["inventory_data"]
    for key, count in inventory.items():
        if count > 0 and key in DECORATIONS:
            item = DECORATIONS[key]
            rows.append([
                InlineKeyboardButton(
                    text=f"Надеть {item['emoji']} {item['name']}",
                    callback_data=f"equip_{key}"
                ),
                InlineKeyboardButton(
                    text=f"Продать ({item['sell']} 🪙)",
                    callback_data=f"sell_{key}"
                ),
            ])
    if pet.get("equipped"):
        rows.append([
            InlineKeyboardButton(text="Снять украшение", callback_data="unequip")
        ])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


async def send_pet(message, user_id):
    pet = apply_time_decay(user_id)
    if not pet or not pet.get("pet_name"):
        await message.answer("🥚 У тебя пока нет питомца. Нажми «Вылупить питомца».")
        return

    image_path = make_pet_image(pet)
    caption = pet_caption(pet)

    if image_path and image_path.exists():
        await message.answer_photo(
            FSInputFile(image_path),
            caption=caption,
            reply_markup=care_keyboard()
        )
    else:
        await message.answer(
            caption + "\n\n⚠️ Не нашёл файл картинки в папке pet_images.",
            reply_markup=care_keyboard()
        )


async def send_level_up(message, levels):
    if levels > 0:
        await message.answer(
            f"🎉 Поздравляем! Питомец повысил уровень на {levels}!\n"
            "За каждый новый уровень начислено 25 монет."
        )


# ---------------------------------------------------------
# Команды и меню
# ---------------------------------------------------------

@dp.message(Command("start"))
async def start(message: Message):
    user_id = message.from_user.id
    pet = apply_time_decay(user_id)

    await message.answer(
        "✨ Добро пожаловать в MagicPet!\n"
        "Заботься о питомце, играй с ним, покупай украшения и помогай ему расти!",
        reply_markup=main_keyboard
    )

    if pet and pet.get("pet_name"):
        await send_pet(message, user_id)
    else:
        await message.answer("🥚 У тебя пока нет питомца. Нажми «Вылупить питомца»!")


@dp.message(Command("profile"))
async def profile_command(message: Message):
    await send_pet(message, message.from_user.id)


@dp.message(F.text == "🥚 Вылупить питомца")
async def hatch(message: Message):
    user_id = message.from_user.id
    existing = get_pet(user_id)

    if existing and existing.get("pet_name"):
        await message.answer(
            "У тебя уже есть питомец! 🐾\n"
            "Я не буду заменять его, чтобы ты случайно не потерял прогресс.\n"
            "Посмотреть питомца можно кнопкой «Мой питомец»."
        )
        return

    pet = random.choice(PETS)
    username = message.from_user.username or message.from_user.first_name or "Игрок"
    save_new_pet(user_id, username, pet)

    await message.answer(
        f"🎉 Из яйца вылупился {pet['emoji']} {pet['name']}!\n"
        "Позаботься о своём новом друге!"
    )
    await send_pet(message, user_id)


@dp.message(F.text == "🐾 Мой питомец")
async def my_pet(message: Message):
    await send_pet(message, message.from_user.id)


@dp.message(F.text.in_({"🎮 Поиграть", "🎮 Мини-игры"}))
async def games_menu(message: Message):
    pet = apply_time_decay(message.from_user.id)
    if not pet or not pet.get("pet_name"):
        await message.answer("Сначала вылупи питомца! 🥚")
        return
    await message.answer("Выбери игру:", reply_markup=games_keyboard())


@dp.message(F.text == "🛍️ Магазин")
@dp.message(F.text == "👑 Украшения")
async def shop_menu(message: Message):
    pet = apply_time_decay(message.from_user.id)
    if not pet or not pet.get("pet_name"):
        await message.answer("Сначала вылупи питомца! 🥚")
        return
    lines = ["🛍️ Магазин украшений", f"У тебя {pet['coins']} 🪙\n"]
    for item in DECORATIONS.values():
        lines.append(f"{item['emoji']} {item['name']} — {item['price']} 🪙")
    await message.answer("\n".join(lines), reply_markup=shop_keyboard())


async def send_inventory(message: Message, user_id: int):
    pet = apply_time_decay(user_id)
    if not pet or not pet.get("pet_name"):
        await message.answer("Сначала вылупи питомца! 🥚")
        return

    inventory = pet["inventory_data"]
    lines = ["🎒 Твой инвентарь:"]
    has_items = False
    for key, count in inventory.items():
        if count > 0 and key in DECORATIONS:
            item = DECORATIONS[key]
            lines.append(f"{item['emoji']} {item['name']} × {count}")
            has_items = True
    if not has_items:
        lines.append("Пока пусто. Загляни в магазин!")
    await message.answer(
        "\\n".join(lines),
        reply_markup=inventory_keyboard(pet)
    )


@dp.message(F.text == "🎒 Инвентарь")
async def inventory_menu(message: Message):
    await send_inventory(message, message.from_user.id)

# ---------------------------------------------------------
# Покупка, надевание, снятие и продажа
# ---------------------------------------------------------

@dp.callback_query(F.data.startswith("buy_"))
async def buy_decoration(callback: CallbackQuery):
    key = callback.data.removeprefix("buy_")
    if key not in DECORATIONS:
        await callback.answer("Такого украшения нет.", show_alert=True)
        return

    pet = apply_time_decay(callback.from_user.id)
    if not pet:
        await callback.answer("Сначала вылупи питомца!", show_alert=True)
        return

    item = DECORATIONS[key]
    if pet["coins"] < item["price"]:
        await callback.answer("Не хватает монет!", show_alert=True)
        return

    inventory = pet["inventory_data"]
    inventory[key] = inventory.get(key, 0) + 1
    update_pet_fields(
        callback.from_user.id,
        coins=pet["coins"] - item["price"],
        inventory=json.dumps(inventory, ensure_ascii=False)
    )
    await callback.answer(f"Куплено: {item['name']}!")
    await callback.message.answer(
        f"🎉 Ты купил {item['emoji']} {item['name']}!\n"
        "Открой «Инвентарь», чтобы надеть украшение или продать его."
    )


@dp.callback_query(F.data.startswith("equip_"))
async def equip_decoration(callback: CallbackQuery):
    key = callback.data.removeprefix("equip_")
    pet = apply_time_decay(callback.from_user.id)
    if not pet or key not in DECORATIONS:
        await callback.answer("Не удалось надеть украшение.", show_alert=True)
        return

    inventory = pet["inventory_data"]
    if inventory.get(key, 0) <= 0:
        await callback.answer("У тебя нет этого украшения.", show_alert=True)
        return

    update_pet_fields(callback.from_user.id, equipped=key)
    await callback.answer("Украшение надето!")
    await send_pet(callback.message, callback.from_user.id)


@dp.callback_query(F.data == "unequip")
async def unequip_decoration(callback: CallbackQuery):
    pet = apply_time_decay(callback.from_user.id)
    if not pet:
        await callback.answer("Питомец не найден.", show_alert=True)
        return
    update_pet_fields(callback.from_user.id, equipped="")
    await callback.answer("Украшение снято.")
    await send_pet(callback.message, callback.from_user.id)


@dp.callback_query(F.data.startswith("sell_"))
async def sell_decoration(callback: CallbackQuery):
    key = callback.data.removeprefix("sell_")
    pet = apply_time_decay(callback.from_user.id)
    if not pet or key not in DECORATIONS:
        await callback.answer("Не удалось продать предмет.", show_alert=True)
        return

    inventory = pet["inventory_data"]
    if inventory.get(key, 0) <= 0:
        await callback.answer("Этого предмета нет в инвентаре.", show_alert=True)
        return

    inventory[key] -= 1
    if inventory[key] <= 0:
        inventory.pop(key, None)

    equipped = pet.get("equipped") or ""
    if equipped == key and inventory.get(key, 0) <= 0:
        equipped = ""

    new_coins = pet["coins"] + DECORATIONS[key]["sell"]
    update_pet_fields(
        callback.from_user.id,
        coins=new_coins,
        inventory=json.dumps(inventory, ensure_ascii=False),
        equipped=equipped
    )
    await callback.answer(f"Продано за {DECORATIONS[key]['sell']} монет!")
    await send_inventory(callback.message, callback.from_user.id)


# ---------------------------------------------------------
# Забота о питомце
# ---------------------------------------------------------

@dp.callback_query(F.data.startswith("care_"))
async def care_action(callback: CallbackQuery):
    user_id = callback.from_user.id
    pet = apply_time_decay(user_id)
    if not pet:
        await callback.answer("Сначала вылупи питомца!", show_alert=True)
        return

    action = callback.data.removeprefix("care_")
    if action == "feed":
        if pet["coins"] < 10:
            await callback.answer("Корм стоит 10 монет.", show_alert=True)
            return
        result = add_rewards(user_id, xp=5, coins=-10, hunger=25, happiness=3)
        message = "🍎 Питомец вкусно покушал!"
    elif action == "drink":
        result = add_rewards(user_id, xp=3, thirst=30)
        message = "💧 Питомец попил воды!"
    elif action == "sleep":
        result = add_rewards(user_id, xp=3, energy=35, hunger=-4, thirst=-4)
        message = "😴 Питомец отдохнул!"
    elif action == "wash":
        result = add_rewards(user_id, xp=5, hygiene=35, happiness=4)
        message = "🛁 Теперь питомец чистенький!"
    else:
        await callback.answer("Неизвестное действие.")
        return

    if not result:
        await callback.answer("Питомец не найден.", show_alert=True)
        return
    updated_pet, levels = result
    await callback.answer(message)
    await send_level_up(callback.message, levels)
    await send_pet(callback.message, user_id)


# ---------------------------------------------------------
# Мини-игры с GIF-анимацией
# ---------------------------------------------------------

@dp.callback_query(F.data.startswith("game_"))
async def play_game(callback: CallbackQuery):
    user_id = callback.from_user.id
    pet = apply_time_decay(user_id)
    if not pet:
        await callback.answer("Сначала вылупи питомца!", show_alert=True)
        return

    game = callback.data.removeprefix("game_")
    if pet["energy"] < 10:
        await callback.answer("Питомец устал. Дай ему поспать 😴", show_alert=True)
        return

    if game == "pet":
        result = add_rewards(
            user_id, xp=5, happiness=12, energy=-2
        )
        caption = "❤️ Ты нежно почесал питомца. Он очень доволен!"
        gif_type = "pet"
    elif game == "stick":
        result = add_rewards(
            user_id, xp=10, coins=8, happiness=15,
            energy=-12, hunger=-5, thirst=-4
        )
        caption = "🦴 Питомец побежал за палкой и принёс её обратно! +8 монет"
        gif_type = "stick"
    elif game == "ball":
        result = add_rewards(
            user_id, xp=10, coins=8, happiness=12,
            energy=-10, hunger=-4, thirst=-3
        )
        caption = "🎾 Отличная игра! Питомец поймал мяч! +8 монет"
        gif_type = "ball"
    else:
        await callback.answer("Неизвестная игра.")
        return

    if not result:
        await callback.answer("Питомец не найден.", show_alert=True)
        return

    updated_pet, levels = result
    gif_path = make_game_gif(user_id, gif_type)
    await callback.answer("Игра окончена!")
    if gif_path and gif_path.exists():
        await callback.message.answer_animation(
            FSInputFile(gif_path),
            caption=caption
        )
    else:
        await callback.message.answer(caption)

    await send_level_up(callback.message, levels)
    await send_pet(callback.message, user_id)


# ---------------------------------------------------------
# Запуск
# ---------------------------------------------------------

async def main():
    init_db()
    IMAGE_DIR.mkdir(exist_ok=True)
    GENERATED_DIR.mkdir(exist_ok=True)
    print("MagicPet запущен!")
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
